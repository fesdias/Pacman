package project.pacman.graphics;
import java.awt.image.BufferedImage;

public abstract class Assets {
	
	protected final int width = 16, height = 16;
	protected BufferedImage[] up, down, left, right, dead;
	public Animation upAnimation, downAnimation, leftAnimation, rightAnimation, deadAnimation;
	
	protected void setFrames(BufferedImage[] frames, String path) {
		SpriteSheet sheet = new SpriteSheet(ImageLoader.getInstance().loadImageFile(path));
		for (int i = 0; i < frames.length; i++)
			frames[i] = sheet.crop(width*i, 0, width, height);
	}
	
	protected Animation setAnimation(int speed, BufferedImage[] frames) {
		return new Animation(speed, frames);
	}
	
}
