package project.pacman.labyrinth.objects;

import java.util.ArrayList;
import java.util.Random;

import project.pacman.graphics.GhostAsset;

public abstract class Ghost extends Creature {
	
	protected Player pacman;
	private boolean vulnerable;
	protected final ArrayList<Direction> directions = new ArrayList<Direction>();
	protected Random random;
	private GhostAsset ghostAsset;
		
	Ghost(int x, int y, String ghostName) {
		super(x, y);
		random = new Random();
		ghostAsset = new GhostAsset(ghostName);
	}
	
	public void setPlayer(Player pacman) {
		this.pacman = pacman;
	}
		
	public boolean ghostIsVulnerable() {
		return this.vulnerable;
	}
		
	private void initVulnerableMode() {
		this.vulnerable = true;
	}
	
	protected double findDistance(double distX, double distY) {
		return Math.sqrt((Math.pow(distX, 2)+Math.pow(distY, 2)));
	}
	
	protected void findShortestDirection() {
		
	}
	
	private void updateGhost() {
		
	}
	
	public GhostAsset getGhostAsset() {
		return ghostAsset;
	}
	
	@Override
	public void accept(LabyrinthObjectVisitor visitor) {
		updateGhost();
		visitor.renderGhosts(this);
	}

}
