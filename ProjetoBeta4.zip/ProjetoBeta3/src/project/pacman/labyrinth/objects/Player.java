package project.pacman.labyrinth.objects;

import java.util.ArrayList;

import project.pacman.engine.PacmanGame;
import project.pacman.graphics.Assets;
import project.pacman.graphics.PacmanAsset;

public class Player extends Creature {

	private PacmanGame game;
	private PacmanAsset pacmanAsset;
	
	Player(int x, int y) {
		super(x, y);
		pacmanAsset = new PacmanAsset();
	}
	
	public void setGame(PacmanGame game) {
		this.game = game;
	}
	
	public void update(ArrayList<Wall> walls) {
		pacmanAsset.upAnimation.update();
		pacmanAsset.downAnimation.update();
		pacmanAsset.leftAnimation.update();
		pacmanAsset.rightAnimation.update();
		move(walls);
	}
		
	@Override
	public void move(ArrayList<Wall> walls) {
		moveX(walls);
		moveY(walls);
		/*
		if (getCurrentDirection() == Direction.UP && positionIsValid(walls, x, y-1)) {
			this.getCoordinate().changeCoordinates(x, y-1);
		} else if (getCurrentDirection() == Direction.DOWN && positionIsValid(walls, x, y+1)) {
			this.getCoordinate().changeCoordinates(x, y+1);
		} else if (getCurrentDirection() == Direction.LEFT && positionIsValid(walls, x-1, y)) {
			this.getCoordinate().changeCoordinates(x-1, y);
		} else if (getCurrentDirection() == Direction.RIGHT && positionIsValid(walls, x+1, y)) {
		*/
		
	}
	
	private void moveX(ArrayList<Wall> walls) {
		int x = this.getX(), y = this.getY();
		if (getCurrentDirection() == Direction.RIGHT) {
			
			int tempX = getX() + 1 + colisionBounds.x + colisionBounds.width / 30;
			
			if (wontCollide(walls, tempX, getY()+colisionBounds.y/30) && wontCollide(walls, tempX, getY()+colisionBounds.height+colisionBounds.y/30)) {
				this.getCoordinate().changeCoordinates(x+1, y);
			}
			
		} else if (getCurrentDirection() == Direction.LEFT) {
			
		}
	}

	private void moveY(ArrayList<Wall> walls) {
		
	}
	
	private boolean wontCollide(ArrayList<Wall> walls, int x, int y) {
		return positionIsValid(walls, x, y);
	}

	public Direction getCurrentDirection() {
		if (game.getKeyManager().up)
			return Direction.UP;
		else if (game.getKeyManager().down)
			return Direction.DOWN;
		else if (game.getKeyManager().left)
			return Direction.LEFT;
		else if (game.getKeyManager().right)
			return Direction.RIGHT;
		return null;
	}
	

	public Assets getAsset() {
		return this.pacmanAsset;
	}

	@Override
	public void accept(LabyrinthObjectVisitor visitor) {
		visitor.renderPlayer(this);
	}

}
