package project.pacman.labyrinth.objects;

import java.awt.Rectangle;
import java.util.ArrayList;

public abstract class Creature extends LabyrinthObject {
	
	protected boolean dead;
	protected Rectangle colisionBounds;
	
	Creature(int x, int y) {
		super(x, y);
		setColisionBounds();
		dead = false;
	}

	private void setColisionBounds() {
		colisionBounds = new Rectangle(0, 0, 30, 30);
		colisionBounds.x = 0;
		colisionBounds.y = 0;
		colisionBounds.width = 30;
		colisionBounds.height = 30;
		
	}

	protected abstract void move(ArrayList<Wall> walls);
	
	protected void killCreature() {
		this.dead = true;
	}
	
	protected boolean isDead() {
		return this.dead;
	}
	
	public Rectangle getColisionBounds() {
		return colisionBounds;
	}
}
