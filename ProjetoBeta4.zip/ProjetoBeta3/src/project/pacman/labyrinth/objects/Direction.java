package project.pacman.labyrinth.objects;

public enum Direction {
	UP,
	DOWN,
	LEFT,
	RIGHT;
}
