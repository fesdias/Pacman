package project.pacman.labyrinth.objects;

public class Wall extends LabyrinthObject {
	private int x, y;
	
	Wall(int x, int y) {
		super(x, y);
	}

	@Override
	public void accept(LabyrinthObjectVisitor visitor) {
		visitor.renderWalls(this);
	}
}
