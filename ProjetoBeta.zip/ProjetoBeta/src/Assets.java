import java.awt.image.BufferedImage;

public abstract class Assets {
	
	protected final int width = 16, height = 16;
	protected BufferedImage[] up, down, left, right, dead;
	
	protected abstract void setFrames(BufferedImage[] frames, String path);
	
}
