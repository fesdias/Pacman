
public abstract class GameEngine{
	private LabyrinthMap labyrinthMap;
		
	public abstract void gameLoop();
	
	public GameEngine(LabyrinthMap labyrinthMap) {
		this.labyrinthMap = labyrinthMap;
	}
	
	protected LabyrinthMap getLabyrinthMap() {
		return labyrinthMap;
	}
}
