import java.awt.image.BufferedImage;

public abstract class GhostAsset extends Assets {
	
	protected BufferedImage[] vulnerable, vulnerableTimeLimit; 
}
