
public class Checkpoint {
	private boolean conquered;
	private int x, y;
	
	public Checkpoint(int x, int y) {
		this.x = x;
		this.y = y;
		conquered = false;
	}
	
	public boolean isConquered() {
		return conquered;
	}
	
	private void conquer() {
		conquered = true;
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
}
