import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import org.omg.CORBA.PRIVATE_MEMBER;

public class PacmanGame extends GameEngine {
	
	private int width, height;
	private String title;
	private boolean running;
	
	private Display display;
	private BufferStrategy bs;
	private Graphics graphics;
	private Thread thread;
	private Player player;
	private KeyManager keyManager;
	
	public PacmanGame(LabyrinthMap labyrinthMap, String title, int width, int height) {
		super(labyrinthMap);
		this.title = title;
		this.width = width;
		this.height = height;
		this.running = false;
		keyManager = new KeyManager();		
	}
	
	public KeyManager getKeyManager() {
		return keyManager;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void setPlayer(Player player) {
		this.player = player;
	}
	private void init() {
		running = true;
		display = new Display(title, width, height);
		display.getFrame().addKeyListener(keyManager);
	}
	
	public synchronized void start() {
		if (running)
			return;
		
		running = true;
		thread = new Thread();
		thread.start();
	}
	
	public synchronized void stop() {
		if (!running)
			return;
		
		running = false;
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void update() {
		keyManager.update();
		player.update(this.getLabyrinthMap().walls);
	}
	
	private void render() {
		bs = display.getCanvas().getBufferStrategy();
		if (bs == null) {
			display.getCanvas().createBufferStrategy(3);
			return;
		}
		graphics = bs.getDrawGraphics();
		this.getLabyrinthMap().renderMap(graphics);		
		bs.show();
		graphics.clearRect((int) player.getX(), (int) player.getY(), 30, 30);
		graphics.dispose();
	}
		
	@Override
	public void gameLoop() {
		init();
		while (running) {
			update();
			render();
		}
		stop();
	}
}
