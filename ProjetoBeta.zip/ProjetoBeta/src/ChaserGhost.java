import java.awt.image.BufferedImage;

public class ChaserGhost extends GhostAsset {
	
	public ChaserGhost() {
		up = new BufferedImage[2];
		down = new BufferedImage[2];
		left = new BufferedImage[2];
		right = new BufferedImage[2];
		dead = new BufferedImage[4];
		vulnerable = new BufferedImage[2];
		vulnerableTimeLimit = new BufferedImage[4];
		
		setFrames(up, "resouces/images/SpriteSheets/red_ghost_sheet.png");
		setFrames(down, "resouces/images/SpriteSheets/red_ghost_sheet.png");
		setFrames(left, "resouces/images/SpriteSheets/red_ghost_sheet.png");
		setFrames(right, "resouces/images/SpriteSheets/red_ghost_sheet.png");
		setFrames(vulnerable, "resouces/images/SpriteSheets/vulnerable_ghost_sheet.png");
		setFrames(vulnerableTimeLimit, "resouces/images/SpriteSheets/vulnerable_ghost_sheet.png");
	}
	
	@Override
	protected void setFrames(BufferedImage[] frames, String path) {
		SpriteSheet sheet = new SpriteSheet(new ImageLoader().loadImageFile(path));
		for (int i = 0; i < frames.length; i++)
			frames[i] = sheet.crop(width*i, 0, width, height);
	}

}
