import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class Player {

	private int x, y, xMove, yMove;
	private PacmanGame game;
	private Animation up, down, left, right;
	private Assets pacman;
	
	public Player(int x, int y) {
		this.x = x;
		this.y = y;
		xMove = 0;
		yMove = 0;
		
		pacman = new PacmanAsset();
		up = new Animation(70, pacman.up);
		down = new Animation(70, pacman.down);
		left = new Animation(70, pacman.left);
		right = new Animation(70, pacman.right);
	}
	
	public void update(ArrayList<Wall> walls) {
		move(walls);
	}
	
	public void setGame(PacmanGame game) {
		this.game = game;
	}
	
	public void move(ArrayList<Wall> walls) {
		if (getInput() == 1 && validPosition(walls, x, y-1)) {
			up.start();
			y -= 1;
		} else if (getInput() == 2 && validPosition(walls, x, y+1)) {
			down.start();
			y += 1;
		} else if (getInput() == 3 && validPosition(walls, x-1, y)) {
			left.start();
			x -= 1;
		} else if (getInput() == 4 && validPosition(walls, x+1, y)) {
			right.start();
			x += 1;
		}	
	}
	
	private boolean validPosition(ArrayList<Wall> walls, int x, int y) {
		if (x > -1 && y > -1) {
			for (Wall wall : walls) {
				if (wall.getY()*30-30 == y && wall.getX()*30-30 == x) {
					return false;
				}
			}
		}
		
		return true;
	}

	public int getInput() {
		if (game.getKeyManager().up) {
			yMove = -1;
			xMove = 0;
			return 1;
		} else if (game.getKeyManager().down) {
			yMove = 1;
			xMove = 0;
			return 2;
		} else if (game.getKeyManager().left) {
			xMove = -1;
			yMove = 0;
			return 3;
		} else if (game.getKeyManager().right) {
			xMove = 1;
			yMove = 0;
			return 4;
		}
		return 0;
	}
	
	public void render(Graphics g) {
		g.drawImage(getCurrentAnimationFrame(), (int)x, (int)y, 16, 16, null);
	}

	private BufferedImage getCurrentAnimationFrame() {
		if (xMove < 0) {
			return left.getCurrentFrame();
		} else if (xMove > 0) {
			return right.getCurrentFrame();
		} else if (yMove < 0) {
			return up.getCurrentFrame();
		}
		return down.getCurrentFrame();
	}
	
	public float getX() {
		return x;
	}
	
	public float getY() {
		return y;
	}
	
}
