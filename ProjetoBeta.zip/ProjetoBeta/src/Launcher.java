
public class Launcher {
	
	public static void main(String[] args) {
		LabyrinthMapLoader loader = new LabyrinthMapLoader();
		LabyrinthMap map = loader.loadMapFromFile("resources/maps/labyrinth0.txt");
		PacmanGame game = new PacmanGame(map, "PacMan", map.getWidth(), map.getHeight());
		game.setPlayer(map.getPlayer());
		map.getPlayer().setGame(game);
		game.gameLoop();
	}
}
