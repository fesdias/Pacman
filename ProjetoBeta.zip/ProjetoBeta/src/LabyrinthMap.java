import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

public class LabyrinthMap {
	
	private Player player;
	private ArrayList<Checkpoint> checkpoints;
	protected ArrayList<Wall> walls;
	private int width, height;
	
	protected LabyrinthMap(int width, int height, Player player, ArrayList<Checkpoint> checkpoints, ArrayList<Wall> walls) {
		this.player = player;
		this.checkpoints = checkpoints;
		this.walls = walls;
		this.width = width;
		this.height = height;
		
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void updateMap() {
		
	}
	
	public Player getPlayer() {
		return player;
	}
	
	public void renderMap(Graphics g) {
		
		g.setColor(Color.black);
		for (Wall wall : walls) {
			g.fillRect(wall.getY()*16, wall.getX()*16, 16, 16);
		}
		
		g.setColor(Color.white);
		for (Checkpoint checkpoint : checkpoints) {
			g.setColor(Color.white);
			g.fillRect(checkpoint.getY()*16, checkpoint.getX()*16, 16, 16);
			g.setColor(Color.red);
			g.fillOval(checkpoint.getY()*16, checkpoint.getX()*16, 10, 10);
		}
		
		player.render(g);
	}
	
	public boolean isDone() {
		for (Checkpoint checkpoint : checkpoints) {
			if (!checkpoint.isConquered())
				return false; 		
		}
		return true;
	}
}
