package project.pacman.graphics;

import java.awt.image.BufferedImage;

public class CheckpointAsset {

	private BufferedImage food, powerBall;
	
	public CheckpointAsset() {
		food = ImageLoader.getInstance().loadImageFile("/images/food.png");
		powerBall = ImageLoader.getInstance().loadImageFile("/images/powerball.png");
	}
	
	public BufferedImage getFood() {
		return food;
	}
	
	public BufferedImage getPowerBall() {
		return powerBall;
	}
}
