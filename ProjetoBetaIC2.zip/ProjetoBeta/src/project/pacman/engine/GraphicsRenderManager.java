package project.pacman.engine;

import java.awt.Color;
import java.awt.Graphics2D;

import project.pacman.labyrinth.objects.Checkpoint;
import project.pacman.labyrinth.objects.Direction;
import project.pacman.labyrinth.objects.Ghost;
import project.pacman.labyrinth.objects.LabyrinthObjectVisitor;
import project.pacman.labyrinth.objects.Player;
import project.pacman.labyrinth.objects.Wall;

class GraphicsRenderManager implements LabyrinthObjectVisitor {
	
	private Graphics2D graphics;
	
	public GraphicsRenderManager(Graphics2D graphics) {
		this.graphics = graphics;
	}
	
	@Override
	public void renderPlayer(Player player) {
		if (player.getCurrentDirection() == Direction.UP) {
			graphics.drawImage(player.getAsset().upAnimation.getCurrentFrame(), player.getX(), player.getY(), 30, 30, null);
		} else if (player.getCurrentDirection() == Direction.DOWN) {
			graphics.drawImage(player.getAsset().downAnimation.getCurrentFrame(), player.getX(), player.getY(), 30, 30, null);
		} else if (player.getCurrentDirection() == Direction.LEFT) {
			graphics.drawImage(player.getAsset().leftAnimation.getCurrentFrame(), player.getX(), player.getY(), 30, 30, null);
		} else if (player.getCurrentDirection() == Direction.RIGHT) {
			graphics.drawImage(player.getAsset().rightAnimation.getCurrentFrame(), player.getX(), player.getY(), 30, 30, null);
		}
		
	}

	@Override
	public void renderGhosts(Ghost ghost) {
		graphics.drawImage(ghost.getGhostAsset().rightAnimation.getCurrentFrame(), ghost.getY(), ghost.getX(), 30, 30, null);
	}

	@Override
	public void renderCheckpoints(Checkpoint checkpoint) {
		graphics.setColor(Color.white);
		graphics.fillRect(checkpoint.getY(), checkpoint.getX(), 30, 30);
		if (!checkpoint.isConquered()) {
			graphics.drawImage(checkpoint.getAssets().getFood(), checkpoint.getY()+15, checkpoint.getX()+15, 5, 5, null);
		}
	}	

	@Override
	public void renderWalls(Wall wall) {
		graphics.setColor(Color.black);
		graphics.fillRect(wall.getY(), wall.getX(), 30, 30);
	}

}
