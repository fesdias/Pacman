package project.pacman.engine;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;

import project.pacman.labyrinth.objects.LabyrinthMap;

public abstract class GameEngine {
	
	private LabyrinthMap labyrinthMap;
	protected Graphics2D graphics;
	protected BufferStrategy buffer;
	private KeyManager keyManager;
		
	public abstract void gameLoop();
	
	public GameEngine(LabyrinthMap labyrinthMap) {
		this.labyrinthMap = labyrinthMap;
		keyManager = new KeyManager();
	}
	
	protected LabyrinthMap getLabyrinthMap() {
		return this.labyrinthMap;
	}
	
	public KeyManager getKeyManager() {
		return this.keyManager;
	}	
	
}
