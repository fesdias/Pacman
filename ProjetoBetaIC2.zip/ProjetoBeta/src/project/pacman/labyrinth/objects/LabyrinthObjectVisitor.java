package project.pacman.labyrinth.objects;

public interface LabyrinthObjectVisitor {
	
	public void renderPlayer(Player player);
	public void renderGhosts(Ghost ghost);
	public void renderCheckpoints(Checkpoint checkpoint);
	public void renderWalls(Wall wall);
}
