package project.pacman.labyrinth.objects;

import java.util.ArrayList;

public class ChaserGhost extends Ghost {
	
	ChaserGhost(int x, int y, String ghostName) {
		super(x, y, ghostName);
		
	}
	
	@Override
	public void move(ArrayList<Wall> walls) {
		double targetX = pacman.getX();
		double targetY = pacman.getY();
		double ghostX = this.getX();
		double ghostY = this.getY();
		double dist, distX, distY;
		
		distX = Math.abs(targetX-this.getX());
		distY = Math.abs(targetY-this.getY());
		dist = findDistance(distX, distY);
		
		if (positionIsValid(walls, (int)ghostX, (int)ghostY-1) && findDistance(ghostX, ghostY-1) < dist) {
			distX = ghostX;
			distY = ghostY-1;
		} else if (positionIsValid(walls, (int)ghostX, (int)ghostY+1) && findDistance(ghostX, ghostY+1) < dist) {
			distX = ghostX;
			distY = ghostY+1;
		} else if (positionIsValid(walls, (int)ghostX-1, (int)ghostY) && findDistance(ghostX-1, ghostY) < dist) {
			distX = ghostX-1;
			distY = ghostY;
		} else if (positionIsValid(walls, (int)ghostX+1, (int)ghostY) && findDistance(ghostX+1, ghostY) < dist) {
			distX = ghostX+1;
			distY = ghostY;
		}
		
		this.getCoordinate().changeCoordinates((int)distX, (int)distY);
	}

	

}
