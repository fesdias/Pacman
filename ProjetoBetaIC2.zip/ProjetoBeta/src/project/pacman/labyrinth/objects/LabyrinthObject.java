package project.pacman.labyrinth.objects;

import java.util.ArrayList;

public abstract class LabyrinthObject {
	
	private Coordinate coordinate;
	
	public abstract void accept(LabyrinthObjectVisitor visitor);
	
	LabyrinthObject(int x, int y) {
		coordinate = new Coordinate(x, y);
	}
	
	public int getX() {
		return coordinate.getX();
	}
	
	public int getY() {
		return coordinate.getY();
	}
	
	protected Coordinate getCoordinate() {
		return coordinate;
	}
	
	public boolean isSameCoordinates(int x, int y) {
		return coordinate.isSameCoordinates(x, y);
	}
	
	public boolean isSameCoordinates(Object obj) {
		return coordinate.equals(obj);
	}
	
	public boolean positionIsValid(ArrayList<Wall> list, int x, int y) {
		if (x > -1 && y > -1) {
			for (LabyrinthObject element : list) {
				if (element.isSameCoordinates(x, y))
					return false;
			}	
			return true;
		}
		return false;
	}

}
