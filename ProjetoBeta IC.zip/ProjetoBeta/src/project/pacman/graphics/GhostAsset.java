package project.pacman.graphics;
import java.awt.image.BufferedImage;

public class GhostAsset extends Assets {
	
	protected BufferedImage[] vulnerable, vulnerableTimeLimit;
	protected Animation vulnarableAnimation, vulnarabletimeLimitAnimation;
	
	public GhostAsset(String ghostName) {
		up = new BufferedImage[2];
		down = new BufferedImage[2];
		left = new BufferedImage[2];
		right = new BufferedImage[2];
		vulnerable = new BufferedImage[2];
		vulnerableTimeLimit = new BufferedImage[4];
		dead = new BufferedImage[4];
				
		setFrames(up, "/images/SpriteSheets/"+ghostName+"_ghost_up.png");
		setFrames(down, "/images/SpriteSheets/"+ghostName+"_ghost_down.png");
		setFrames(left, "/images/SpriteSheets/"+ghostName+"_ghost_left.png");
		setFrames(right, "/images/SpriteSheets/"+ghostName+"_ghost_right.png");
		setFrames(dead, "/images/SpriteSheets/ghost_died_sheet.png");
		setFrames(vulnerable, "/images/SpriteSheets/vulnerable_ghost_sheet.png");
		setFrames(vulnerableTimeLimit, "/images/SpriteSheets/vulnerable_ghost_timelimit_sheet.png");
		
		setAnimation(upAnimation, 0, up);
		setAnimation(downAnimation, 0, down);
		setAnimation(leftAnimation, 0, left);
		setAnimation(rightAnimation, 0, right);
		setAnimation(vulnarableAnimation, 0, vulnerable);
		setAnimation(vulnarabletimeLimitAnimation, 0, vulnerableTimeLimit);
		setAnimation(deadAnimation, 0, dead);
	}
}
