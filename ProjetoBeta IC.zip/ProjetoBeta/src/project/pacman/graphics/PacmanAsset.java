package project.pacman.graphics;
import java.awt.image.BufferedImage;

public class PacmanAsset extends Assets{
	
	public PacmanAsset() {
		up = new BufferedImage[4];
		down = new BufferedImage[4];
		left = new BufferedImage[4];
		right = new BufferedImage[4];
		dead = new BufferedImage[14];
		
		setFrames(right, "/images/SpriteSheets/pacman_right_sheet.png");
		setFrames(down, "/images/SpriteSheets/pacman_down_sheet.png");
		setFrames(left, "/images/SpriteSheets/pacman_left_sheet.png");
		setFrames(up, "/images/SpriteSheets/pacman_up_sheet.png");
		setFrames(dead, "/images/SpriteSheets/dead_pacman_sheet.png");
		
		setAnimation(upAnimation, 0, up);
		setAnimation(downAnimation, 0, down);
		setAnimation(leftAnimation, 0, left);
		setAnimation(rightAnimation, 0, right);
		setAnimation(deadAnimation, 0, dead);
	}
}
