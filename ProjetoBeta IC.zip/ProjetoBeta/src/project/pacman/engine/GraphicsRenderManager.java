package project.pacman.engine;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;

import project.pacman.labyrinth.objects.Checkpoint;
import project.pacman.labyrinth.objects.Ghost;
import project.pacman.labyrinth.objects.LabyrinthMap;
import project.pacman.labyrinth.objects.LabyrinthObjectVisitor;
import project.pacman.labyrinth.objects.Player;
import project.pacman.labyrinth.objects.Wall;

class GraphicsRenderManager implements LabyrinthObjectVisitor {
	
	@Override
	public void renderObjects(LabyrinthMap map, Graphics2D graphics) {
		map.accept(this, graphics);
	}

	@Override
	public void renderPlayer(Player player, Graphics2D graphics) {
		
	}

	@Override
	public void renderGhosts(Ghost ghost, Graphics2D graphics) {
		
	}

	@Override
	public void renderCheckpoints(Checkpoint checkpoint, Graphics2D graphics) {
		graphics.setColor(Color.white);
		graphics.fillRect(checkpoint.getY(), checkpoint.getX(), 30, 30);
		graphics.drawImage(checkpoint.getAssets().getFood(), checkpoint.getY()+15, checkpoint.getX()+15, 5, 5, null);
	}

	@Override
	public void renderWalls(Wall wall, Graphics2D graphics) {
		graphics.setColor(Color.black);
		graphics.fillRect(wall.getY(), wall.getX(), 30, 30);
	}

	@Override
	public void showRenderedObjects(BufferStrategy buffer, Graphics2D graphics) {
		buffer.show();
		graphics.dispose();
	}

}
