package project.pacman.engine;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyManager implements KeyListener {
	
	private boolean[] keys;
	public boolean up, down, left, right;
	
	public KeyManager() {
		keys = new boolean[4];
	}
	
	public void update() {
		up = keys[KeyEvent.VK_UP-37];
		down = keys[KeyEvent.VK_DOWN-37];
		left = keys[KeyEvent.VK_LEFT-37];
		right = keys[KeyEvent.VK_RIGHT-37];
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		if (key <= 40 && key >= 37)
			keys[key-37] = true;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();
		if (key <= 40 && key >= 37)
			keys[key-37] = false;
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

}
