package project.pacman.engine;

import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;

import project.pacman.labyrinth.objects.LabyrinthMap;
import project.pacman.labyrinth.objects.Player;


public class PacmanGame extends GameEngine {
	
	private int width, height;
	private String title;
	private boolean running;
	
	private Display display;
	private Thread thread;
	private Player player;
	private GraphicsRenderManager graphicsRenderManager;
	
	public PacmanGame(LabyrinthMap labyrinthMap, String title, int width, int height) {
		super(labyrinthMap);
		this.title = title;
		this.width = width;
		this.height = height;
		this.running = false;
		graphicsRenderManager = new GraphicsRenderManager();
	}
	
	public void setPlayer(Player player) {
		this.player = player;
	}
	private void init() {
		display = new Display(title, width, height);
		display.getFrame().addKeyListener(this.getKeyManager());
		display.getCanvas().createBufferStrategy(3);
		buffer = display.getCanvas().getBufferStrategy();
		graphics = (Graphics2D) buffer.getDrawGraphics();
		start();
	}
	
	public synchronized void start() {
		if (running)
			return;
		
		running = true;
		thread = new Thread();
		thread.start();
	}
	
	public synchronized void stop() {
		if (!running)
			return;
		
		running = false;
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
		
	/*private void render() {
		bs = display.getCanvas().getBufferStrategy();
		graphics = (Graphics2D) bs.getDrawGraphics();
		this.getLabyrinthMap().renderMap(graphics);		
		bs.show();
		graphics.clearRect(player.getX(), player.getY(), 20, 20);
		graphics.dispose();
	}*/
		
	@Override
	public void gameLoop() {
		init();
		while (running) {
			graphicsRenderManager.renderObjects(this.getLabyrinthMap(), graphics);
			graphicsRenderManager.showRenderedObjects(buffer, graphics);
			
		}
		stop();
	}
}
