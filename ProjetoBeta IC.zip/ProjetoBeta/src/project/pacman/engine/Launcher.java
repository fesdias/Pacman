package project.pacman.engine;

import project.pacman.labyrinth.objects.LabyrinthMap;
import project.pacman.labyrinth.objects.LabyrinthMapLoader;

public class Launcher {
	
	private static void run(GameEngine game) {
		game.gameLoop();
	}
	
	public static void main(String[] args) {
		LabyrinthMap map = LabyrinthMapLoader.getInstance().loadMapFromFile("resources/maps/labyrinth0.txt");
		run(new PacmanGame(map, "Pacman", map.getWidth(), map.getHeight()));
	}
}
