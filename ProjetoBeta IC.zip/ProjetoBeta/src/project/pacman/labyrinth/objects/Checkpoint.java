package project.pacman.labyrinth.objects;

import java.awt.Graphics2D;

import project.pacman.graphics.CheckpointAsset;


public class Checkpoint extends LabyrinthObject {
	
	private boolean conquered;
	private CheckpointAsset checkpointAsset;
	
	Checkpoint(int x, int y) {
		super(x, y);
		conquered = false;
		checkpointAsset = new CheckpointAsset();
	}
	
	public boolean isConquered() {
		return conquered;
	}
	
	void conquer() {
		conquered = true;
	}
	
	public CheckpointAsset getAssets() {
		return this.checkpointAsset;
	}
	
	private void updateCheckpoint() {
		
	}

	@Override
	public void accept(LabyrinthObjectVisitor visitor, Graphics2D graphics) {
		updateCheckpoint();
		visitor.renderCheckpoints(this, graphics);
	}

}
