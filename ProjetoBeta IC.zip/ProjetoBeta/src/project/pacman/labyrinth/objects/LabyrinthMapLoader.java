package project.pacman.labyrinth.objects;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class LabyrinthMapLoader {
	
	private static LabyrinthMapLoader mapLoader;
	private final int graphicalScale = 20;
	
	private LabyrinthMapLoader() {
	}
	
	public static LabyrinthMapLoader getInstance() {
		if (mapLoader == null) {
			return new LabyrinthMapLoader();
		}
		return mapLoader;
	}
	
	public LabyrinthMap loadMapFromFile(String path) {
		ArrayList<Checkpoint> checkpoints = null;
		ArrayList<Wall> walls = null;
		ArrayList<Ghost> ghosts = null;
		int i = 0, j = 0, inicialX = 0, inicialY = 0;
		try {
			File file = new File(path);
			FileReader reader = new FileReader(file);
			BufferedReader buff = new BufferedReader(reader);
			String line = buff.readLine();
			
			checkpoints = new ArrayList<Checkpoint>();
			walls = new ArrayList<Wall>();
			ghosts = new ArrayList<Ghost>();
			
			while(line != null) {
				while (j < line.length()) {
					if (line.charAt(j) == '0' || line.charAt(j) == '#') {
						walls.add(new Wall(i*graphicalScale, j*graphicalScale));
					} else if (line.charAt(j) == '*'){
						checkpoints.add(new Checkpoint(i*graphicalScale, j*graphicalScale));
					}  else if (line.charAt(j) == '1'){
						checkpoints.add(new Checkpoint(i*graphicalScale, j*graphicalScale));
						inicialX = i;
						inicialY = j;
					} else if (line.charAt(j) == '2') {
						walls.add(new Wall(i*graphicalScale, j*graphicalScale));
						ghosts.add(new ChaserGhost(i, j, "chaser"));
					} else if (line.charAt(j) == '3') {
						walls.add(new Wall(i*graphicalScale, j*graphicalScale));
						ghosts.add(new WatcherGhost(i, j, "watcher"));
					} else if (line.charAt(j) == '4') {
						walls.add(new Wall(i*graphicalScale, j*graphicalScale));
						ghosts.add(new RandomGhost(i, j, "random"));
					} else if (line.charAt(j) == '5') {
						walls.add(new Wall(i*graphicalScale, j*graphicalScale));
						ghosts.add(new EvasiveGhost(i, j, ghosts, "evasive"));
					}
					j++;
				}
				i++;
				line = buff.readLine();
				if (line != null)
					j = 0;
			}
			buff.close();
			reader.close();
		} catch (IOException e) {
			System.out.println("Arquivo não encontrado");
		}
		Player player = new Player(inicialY*20, inicialX*20);
		ghosts.get(0).setPlayer(player);
		return new LabyrinthMap(j*graphicalScale+9, i*graphicalScale, player, checkpoints, walls, ghosts);
	}
}
