package project.pacman.labyrinth.objects;

import java.awt.Graphics2D;
import java.util.ArrayList;

import project.pacman.engine.PacmanGame;
import project.pacman.graphics.Assets;
import project.pacman.graphics.PacmanAsset;

public class Player extends LabyrinthObject {

	private PacmanGame game;
	private PacmanAsset pacmanAsset;
	
	Player(int x, int y) {
		super(x, y);
		pacmanAsset = new PacmanAsset();
	}
	
	public void setGame(PacmanGame game) {
		this.game = game;
	}
	
	public void move(ArrayList<LabyrinthObject> walls) {
		int x = this.getX(), y = this.getY();
		if (getCurrentDirection() == Direction.UP && positionIsValid(walls, x, y-1)) {
			this.getCoordinate().changeCoordinates(x, y-1);
		} else if (getCurrentDirection() == Direction.DOWN && positionIsValid(walls, x, y+1)) {
			this.getCoordinate().changeCoordinates(x, y+1);
		} else if (getCurrentDirection() == Direction.LEFT && positionIsValid(walls, x-1, y)) {
			this.getCoordinate().changeCoordinates(x-1, y);
		} else if (getCurrentDirection() == Direction.RIGHT && positionIsValid(walls, x+1, y)) {
			this.getCoordinate().changeCoordinates(x+1, y);
		}
	}
	
	private Direction getCurrentDirection() {
		if (game.getKeyManager().up)
			return Direction.UP;
		else if (game.getKeyManager().down)
			return Direction.DOWN;
		else if (game.getKeyManager().left)
			return Direction.LEFT;
		else if (game.getKeyManager().right)
			return Direction.RIGHT;
		return null;
	}
	
	public Assets getAsset() {
		return this.pacmanAsset;
	}

	@Override
	public void accept(LabyrinthObjectVisitor visitor, Graphics2D graphics) {
		visitor.renderPlayer(this, graphics);
	}

}
