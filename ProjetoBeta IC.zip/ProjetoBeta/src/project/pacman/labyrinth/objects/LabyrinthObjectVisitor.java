package project.pacman.labyrinth.objects;

import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;

public interface LabyrinthObjectVisitor {
	
	public void renderObjects(LabyrinthMap map, Graphics2D graphics);
	public void renderPlayer(Player player, Graphics2D graphics);
	public void renderGhosts(Ghost ghost, Graphics2D graphics);
	public void renderCheckpoints(Checkpoint checkpoint, Graphics2D graphics);
	public void renderWalls(Wall wall, Graphics2D graphics);
	public void showRenderedObjects(BufferStrategy buffer, Graphics2D graphics);
}
