package project.pacman.labyrinth.objects;

import java.util.ArrayList;

public class RandomGhost extends Ghost {
	
	RandomGhost(int x, int y, String ghostName) {
		super(x, y, ghostName);	
	}

	@Override
	public void move(ArrayList<LabyrinthObject> walls) {
		int index = random.nextInt(directions.size());
		int x = this.getX(), y = this.getY();
		while (true) {
			if (directions.get(index) == Direction.UP && positionIsValid(walls, x, y-1)) {
				this.getCoordinate().changeCoordinates(x, y-1);
				break;
			} else if (directions.get(index) == Direction.DOWN && positionIsValid(walls, x, y+1)) {
				this.getCoordinate().changeCoordinates(x, y-1);
				break;
			} else if (directions.get(index) == Direction.LEFT && positionIsValid(walls, x-1, y)) {
				this.getCoordinate().changeCoordinates(x, y-1);
				break;
			} else if (directions.get(index) == Direction.RIGHT && positionIsValid(walls, x+1, y)) {
				this.getCoordinate().changeCoordinates(x, y-1);
				break;
			} else {
				index = random.nextInt(directions.size());
			}
		}
	}

}
