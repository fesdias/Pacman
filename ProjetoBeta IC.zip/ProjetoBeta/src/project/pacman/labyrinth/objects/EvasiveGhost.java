package project.pacman.labyrinth.objects;

import java.util.ArrayList;

public class EvasiveGhost extends Ghost {

	private ArrayList<Ghost> ghosts;
	
	EvasiveGhost(int x, int y, ArrayList<Ghost> ghosts, String ghostName) {
		super(x, y, ghostName);
		this.ghosts = ghosts;
	}
	

	@Override
	public void move(ArrayList<LabyrinthObject> walls) {
		double dist, x = this.getX(), y = this.getY();
		double[] newDist = new double[4];
		
		dist = sumDistances(x, y);
		if (positionIsValid(walls, (int)x, (int)y-1)) {
			newDist[0] = sumDistances(x, y-1);
		} 
		if (positionIsValid(walls, (int)x, (int)y+1)) {
			newDist[1] = sumDistances(x, y+1);
		}
		if (positionIsValid(walls, (int)x-1, (int)y)) {
			newDist[2] = sumDistances(x-1, y);
		}
		if (positionIsValid(walls, (int)x+1, (int)y)) {
			newDist[3] = sumDistances(x+1, y);
		}
		
		for (int i = 0; i < newDist.length; i++) {
			if (newDist[i] < dist)
				dist = newDist[i];
			for (int j = i+1; j < newDist.length; j++)
				if (newDist[j] < dist)
					dist = newDist[j];
		}
		if (dist == newDist[0]) {
			this.getCoordinate().changeCoordinates((int)x, (int)y-1);
		} else if (dist == newDist[1]) {
			this.getCoordinate().changeCoordinates((int)x, (int)y+1);
		} else if (dist == newDist[2]) {
			this.getCoordinate().changeCoordinates((int)x-1, (int)y);
		} else if (dist == newDist[3]) {
			this.getCoordinate().changeCoordinates((int)x+1, (int)y);
		}
	}

	private double sumDistances(double x, double y) {
		double dist = 0, distX, distY;
		for (int i = 0; i < ghosts.size(); i++) {
			distX = Math.abs(ghosts.get(i).getX() - x);
			distY = Math.abs(ghosts.get(i).getY() - y);
			dist += findDistance(distX, distY);
		}
		return dist;
	}

}
