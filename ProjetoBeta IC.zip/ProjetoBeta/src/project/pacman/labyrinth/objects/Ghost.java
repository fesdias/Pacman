package project.pacman.labyrinth.objects;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Random;

import project.pacman.graphics.GhostAsset;

public abstract class Ghost extends LabyrinthObject {
	
	protected Player pacman;
	private boolean dead, vulnerable;
	protected final ArrayList<Direction> directions = new ArrayList<Direction>();
	protected Random random;
	private GhostAsset ghostAsset;
		
	public abstract void move(ArrayList<LabyrinthObject> list);
	
	Ghost(int x, int y, String ghostName) {
		super(x, y);
		random = new Random();
		ghostAsset = new GhostAsset(ghostName);
	}
	
	public void setPlayer(Player pacman) {
		this.pacman = pacman;
	}
	
	public boolean ghostIsDead() {
		return this.dead;
	}
	
	public boolean ghostIsVulnerable() {
		return this.vulnerable;
	}
	
	public void killGhost() {
		this.dead = true;
	}
	
	public void initVulnerableMode() {
		this.vulnerable = true;
	}
	
	protected double findDistance(double distX, double distY) {
		return Math.sqrt((Math.pow(distX, 2)+Math.pow(distY, 2)));
	}
	
	protected void findShortestDirection() {
		
	}
	
	private void updateGhost() {
		
	}
	
	@Override
	public void accept(LabyrinthObjectVisitor visitor, Graphics2D graphics) {
		updateGhost();
		visitor.renderGhosts(this, graphics);
	}

}
