package project.pacman.labyrinth.objects;

import java.util.ArrayList;

public class WatcherGhost extends Ghost {

	WatcherGhost(int x, int y, String ghostName) {
		super(x, y, ghostName);
		
	}

	@Override
	public void move(ArrayList<LabyrinthObject> checkpoints) {
		int index = random.nextInt(checkpoints.size());
		int x = checkpoints.get(index).getX();
		int y = checkpoints.get(index).getY();
		this.getCoordinate().changeCoordinates(x, y);
	}

}
