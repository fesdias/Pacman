package project.pacman.labyrinth.objects;

import java.awt.Graphics2D;
import java.util.ArrayList;

public class LabyrinthMap {
	
	private Player player;
	private ArrayList<Checkpoint> checkpoints;
	private ArrayList<Wall> walls;
	private ArrayList<Ghost> ghosts;
	private int width, height;
	
	protected LabyrinthMap(int width, int height, Player player, ArrayList<Checkpoint> checkpoints, ArrayList<Wall> walls, ArrayList<Ghost> ghosts) {
		this.player = player;
		this.checkpoints = checkpoints;
		this.walls = walls;
		this.ghosts = ghosts;
		this.width = width;
		this.height = height;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void updateMap() {
		
	}
	
	public Player getPlayer() {
		return player;
	}
	
	public void accept(LabyrinthObjectVisitor visitor, Graphics2D graphics) {
		for (Wall wall : walls) {
			wall.accept(visitor, graphics);
		}
		
		for (Checkpoint checkpoint : checkpoints) {
			checkpoint.accept(visitor, graphics);
		}
		
		for (Ghost ghost : ghosts) {
			ghost.accept(visitor, graphics);
		}
		
		player.accept(visitor, graphics);
	}
	
	public boolean isDone() {
		for (Checkpoint checkpoint : checkpoints) {
			if (!checkpoint.isConquered())
				return false; 		
		}
		return true;
	}
	
}
