package project.pacman.labyrinth.objects;

import java.awt.Graphics2D;

public class Wall extends LabyrinthObject {
	private int x, y;
	
	Wall(int x, int y) {
		super(x, y);
	}

	@Override
	public void accept(LabyrinthObjectVisitor visitor, Graphics2D graphics) {
		visitor.renderWalls(this, graphics);
	}
}
